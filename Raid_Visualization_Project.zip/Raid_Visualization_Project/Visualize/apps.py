from django.apps import AppConfig


class VisualizeConfig(AppConfig):
    name = 'Visualize'
